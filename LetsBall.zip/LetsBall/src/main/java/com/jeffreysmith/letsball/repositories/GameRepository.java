package com.jeffreysmith.letsball.repositories;

import java.util.List;

import org.springframework.data.repository.ListCrudRepository;
import org.springframework.stereotype.Repository;

import com.jeffreysmith.letsball.models.Game;

@Repository
public interface GameRepository  extends ListCrudRepository<Game, Long>{
	List<Game> findAllByOrderByNameAsc();
	List<Game> findByNameContaining(String location);
}
