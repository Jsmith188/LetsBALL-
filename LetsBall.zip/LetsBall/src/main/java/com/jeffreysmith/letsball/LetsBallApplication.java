package com.jeffreysmith.letsball;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LetsBallApplication {

	public static void main(String[] args) {
		SpringApplication.run(LetsBallApplication.class, args);
	}

}
