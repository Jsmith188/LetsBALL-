package com.jeffreysmith.letsball.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jeffreysmith.letsball.models.Game;
import com.jeffreysmith.letsball.repositories.GameRepository;
import com.jeffreysmith.letsball.repositories.UserRepository;

@Service
public class GameService {
	@Autowired
	GameRepository gRepo;
	
	@Autowired
	UserRepository uRepo;

	public List<Game> getAll() {
		return gRepo.findAll();
	}

	public List<Game> getAllByNameAsc() {
		return gRepo.findAllByOrderByNameAsc();
	}
	
	public List<Game> searchGames(String query){
		return gRepo.findByNameContaining(query);
	}

	public void createGame(Game game) {
		gRepo.save(game);
	}

	public Game getOneGame(Long id) {
		Optional<Game> optionalGame = gRepo.findById(id);
		if (optionalGame.isPresent()) {
			return optionalGame.get();
		} else {
			return null;
		}
	}

	public Game update(Game game) {
		return gRepo.save(game);
	}
	
	public void deleteGame(Long id) {
		gRepo.deleteById(id);
	}

}
	
	